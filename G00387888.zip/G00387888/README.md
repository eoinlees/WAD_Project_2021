# WAD_Project_2021
## Eoin Lees - G00387888

The following is the Web application and Development project for 2021. 

To view the project do the following:

* Navigate to the folder in the console. 
* run python -m http.server in the console
* open local host:8000 in a web browser
* click startHere.html

This will load up the lading page from the project.<br> From there follow the links to the login page then enter the login details provided. 
<br> The main menu has links to all of the projects functionality. 

<b>Note:</b><br>
The update data functionality in the pie chart has not been figured out. It currently reads the default data and creates the chart based on this. If it is changed in the code and rerun it does change the values. Some more debugging is needed to get this working fully. 

----------------------
